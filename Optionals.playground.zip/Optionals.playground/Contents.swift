import Cocoa

//*Objective - declaring an optional instance
/*var errorCodeString: Optional<String>
errorCodeString = Optional("404")*/

//*Objective - using shorthand optional syntax
  var errorCodeString: String?
  errorCodeString = "404"
var errorDescription: String?

//*Objective - Logging the value of the optional to the console
//print(errorCodeString)

//*Objective - adding a condition
/*if errorCodeString != nil {
    let theError = errorCodeString!
    print(theError)
}
*/

//*Objective - Optional Binding
if let theError = errorCodeString,



//*Objective - Nesting optional binding
/*if let errorCodeInt = Int(theError) {
    print("\(theError): \(errorCodeInt)")
}
} */

//*Objective - Unwrapping multiple optionals
/*if let theError = errorCodeString,
   let errorCodeInt = Int(theError) {
    print("\(theError): \(errorCodeInt)")
}
}*/

//*Objective - Optional binding and additional checks
/*if let theError = errorCodeString,
    let errorCodeInt = Int(theError),
   errorCodeInt == 404 {
    print("\(theError): \(errorCodeInt)")
}
}
*/

//*Objective - Optional Chaining
   let errorCodeInt = Int(theError),
       errorCodeInt == 404 {
   errorDescription =
    "\(errorCodeInt + 200): resource not found. "
}
var upCaseErrorDescription =
errorDescription?.uppercased()

//*Objective - Modifying an Optional in Place
upCaseErrorDescription?.append("PLEASE TRY AGAIN.")
upCaseErrorDescription


//*Objective - Using Optional biding to parse errorDescription
/*let description: String
if let errorDescription = errorDescription {
    description = errorDescription
} else {
    description = "No error."
} */

//*Objective - Using the Nil coalescing operator
//let description = errorDescription ?? "No error."


//*Objective - changing errorDescription.
 errorDescription = nil
let description = errorDescription ?? "No error."
